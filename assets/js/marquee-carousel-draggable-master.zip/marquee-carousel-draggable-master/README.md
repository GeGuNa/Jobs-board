# Infinite Marquee Carousel With Pure Vanilla JavaScript
This is a little project of pure vanilla JavaScript Infinite Marquee Carousel. 

Feature: 
- pause on hover
- draggable
